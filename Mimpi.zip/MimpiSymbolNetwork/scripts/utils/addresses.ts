export const addresses = {
  mainnet: {
    uniswapV3Router: "0xE592427A0AEce92De3Edee1F18E0157C05861564",
    uniswapV3PositionManager: "0xC36442b4a4522E871399CD717aBDD847Ab11FE88",
    weth: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
  },
  goerli: {
    uniswapV3Router: "0xE592427A0AEce92De3Edee1F18E0157C05861564",
    uniswapV3PositionManager: "0xC36442b4a4522E871399CD717aBDD847Ab11FE88",
    weth: "0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6",
  },
};

export default addresses;
