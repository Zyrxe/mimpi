import { ethers, upgrades } from "hardhat";

async function main() {
  console.log("Deploying MIMPI Token...");

  const [deployer] = await ethers.getSigners();
  console.log("Deploying with account:", deployer.address);

  const Token = await ethers.getContractFactory("MIMPIToken");
  const token = await upgrades.deployProxy(Token, [deployer.address], {
    initializer: "initialize",
  });
  
  await token.waitForDeployment();
  const tokenAddress = await token.getAddress();
  
  console.log("MIMPI Token deployed to:", tokenAddress);

  return tokenAddress;
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
