import { ethers } from "hardhat";

async function main() {
  console.log("Deploying Vesting Contracts...");

  const [deployer] = await ethers.getSigners();
  const tokenAddress = process.env.TOKEN_ADDRESS || "";

  const TeamVestingFactory = await ethers.getContractFactory("TeamVestingFactory");
  const teamVestingFactory = await TeamVestingFactory.deploy(tokenAddress);
  await teamVestingFactory.waitForDeployment();
  console.log("TeamVestingFactory deployed to:", await teamVestingFactory.getAddress());

  const InvestorVesting = await ethers.getContractFactory("InvestorVesting");
  const investorVesting = await InvestorVesting.deploy(tokenAddress);
  await investorVesting.waitForDeployment();
  console.log("InvestorVesting deployed to:", await investorVesting.getAddress());
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
