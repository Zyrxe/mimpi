import { useState } from 'react'

export default function Home() {
  const [account, setAccount] = useState<string | null>(null)

  const connectWallet = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' })
        setAccount(accounts[0])
      } catch (error) {
        console.error('Failed to connect wallet:', error)
      }
    } else {
      alert('Please install MetaMask to use this dApp')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold text-white mb-4">
            MIMPI Token
          </h1>
          <p className="text-2xl text-blue-200">
            Advanced DeFi Ecosystem
          </p>
        </div>

        <div className="max-w-4xl mx-auto grid gap-8 md:grid-cols-2">
          <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-2xl p-8 text-white">
            <h2 className="text-3xl font-bold mb-4">Token Info</h2>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-300">Name:</span>
                <span className="font-semibold">MIMPI</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Symbol:</span>
                <span className="font-semibold">MP</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Initial Supply:</span>
                <span className="font-semibold">1,000,000,000 MP</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Auto Burn:</span>
                <span className="font-semibold">5%</span>
              </div>
            </div>
          </div>

          <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-2xl p-8 text-white">
            <h2 className="text-3xl font-bold mb-4">Features</h2>
            <ul className="space-y-2 text-gray-200">
              <li className="flex items-center">
                <span className="mr-2">✓</span>
                Governance & Voting
              </li>
              <li className="flex items-center">
                <span className="mr-2">✓</span>
                Staking Rewards
              </li>
              <li className="flex items-center">
                <span className="mr-2">✓</span>
                Liquidity Management
              </li>
              <li className="flex items-center">
                <span className="mr-2">✓</span>
                Anti-Dump Mechanisms
              </li>
              <li className="flex items-center">
                <span className="mr-2">✓</span>
                Treasury & Buyback
              </li>
            </ul>
          </div>

          <div className="md:col-span-2 bg-white bg-opacity-10 backdrop-blur-lg rounded-2xl p-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Connect Your Wallet</h2>
            {account ? (
              <div>
                <p className="text-green-300 mb-2">Connected!</p>
                <p className="text-gray-300 font-mono text-sm">
                  {account.slice(0, 6)}...{account.slice(-4)}
                </p>
              </div>
            ) : (
              <button
                onClick={connectWallet}
                className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:from-purple-600 hover:to-indigo-700 transition-all transform hover:scale-105"
              >
                Connect Wallet
              </button>
            )}
          </div>
        </div>

        <div className="text-center mt-16 text-gray-400">
          <p>Built with Next.js, Hardhat, and Ethers.js</p>
        </div>
      </div>
    </div>
  )
}
