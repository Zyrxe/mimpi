# MIMPI Token - Advanced DeFi Ecosystem

![MIMPI Logo](docs/logo.png)

## Overview

MIMPI Token (MP) is a comprehensive DeFi ecosystem built on Ethereum featuring governance, staking, liquidity management, anti-dump mechanisms, and treasury operations.

## Token Information

- **Name**: MIMPI
- **Symbol**: MP
- **Network**: Ethereum Mainnet
- **Compiler**: Solidity ^0.8.27
- **Initial Supply**: 1,000,000,000 MP
- **Auto Burn**: 5% (executed during deployment)

## Features

### Core Token Features
- ✅ ERC-20 Upgradeable (UUPS Proxy)
- ✅ Burnable & Mintable (Role-based)
- ✅ Pausable (Emergency Control)
- ✅ Permit (EIP-2612 Gasless Approvals)
- ✅ Snapshot & Voting (Governance)

### Ecosystem Components

#### 1. **Liquidity Management**
- Liquidity Locker for LP tokens
- LP Token Wrapper for staking integration

#### 2. **Staking System**
- Multi-pool staking with customizable rewards
- Vote-Escrowed Token (veMP) for governance
- Reward distribution scheduler

#### 3. **Treasury & Fund Management**
- Multi-signature treasury with role-based access
- Fund distributor for ecosystem allocations

#### 4. **Vesting Contracts**
- Team vesting with cliff and linear release
- Investor vesting with revocable schedules
- Vesting factory for batch deployments

#### 5. **Oracles & Monitoring**
- Price oracle for token valuation
- Volatility oracle for market analysis
- Circuit breaker for emergency situations
- Event logger for comprehensive tracking

## Project Structure

```
├── contracts/          # Smart contracts
│   ├── token/         # Core token contracts
│   ├── liquidity/     # Liquidity management
│   ├── staking/       # Staking and rewards
│   ├── treasury/      # Treasury management
│   ├── vesting/       # Token vesting
│   ├── oracles/       # Price & volatility oracles
│   └── monitoring/    # Circuit breaker & logging
├── scripts/           # Deployment scripts
├── tests/             # Contract tests
├── frontend/          # Next.js web application
└── docs/              # Documentation

```

## Getting Started

### Prerequisites

- Node.js v20+
- MetaMask or compatible Web3 wallet
- Ethereum testnet/mainnet RPC endpoint
- Etherscan API key (for verification)

### Installation

```bash
# Install dependencies
npm install

# Install frontend dependencies
cd frontend && npm install
```

### Compilation

```bash
# Compile smart contracts
npx hardhat compile
```

### Deployment

```bash
# Deploy token contract
npx hardhat run scripts/deploy/deploy_token.ts --network mainnet

# Deploy other contracts
npx hardhat run scripts/deploy/deploy_staking.ts --network mainnet
npx hardhat run scripts/deploy/deploy_treasury.ts --network mainnet
npx hardhat run scripts/deploy/deploy_vesting.ts --network mainnet
npx hardhat run scripts/deploy/deploy_oracles.ts --network mainnet
```

### Frontend Development

```bash
# Start development server
cd frontend
npm run dev
```

The frontend will be available at `http://localhost:5000`

## Configuration

Create a `.env` file in the root directory:

```env
PRIVATE_KEY=your_deployer_private_key
MAINNET_RPC=https://eth-mainnet.g.alchemy.com/v2/your_api_key
ETHERSCAN_API_KEY=your_etherscan_api_key
```

⚠️ **Never commit your `.env` file to version control!**

## Smart Contract Architecture

See [docs/architecture.md](docs/architecture.md) for detailed contract architecture.

## Tokenomics

See [docs/tokenomics.md](docs/tokenomics.md) for token distribution and economics.

## Security

- All contracts inherit from OpenZeppelin's audited libraries
- UUPS upgradeable pattern for future improvements
- Role-based access control (RBAC) for administrative functions
- Circuit breaker for emergency situations
- Time-locked governance actions

## Testing

```bash
# Run all tests
npx hardhat test

# Run with coverage
npx hardhat coverage
```

## License

MIT License - see LICENSE file for details

## Support

For issues, questions, or contributions, please open an issue on GitHub.

## Disclaimer

This is experimental software. Use at your own risk. Always perform due diligence and audits before deploying to mainnet.
