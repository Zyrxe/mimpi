import { run } from "hardhat";

async function main() {
  console.log("Verifying contracts on Etherscan...");

  const tokenAddress = process.env.TOKEN_ADDRESS || "";

  try {
    await run("verify:verify", {
      address: tokenAddress,
      constructorArguments: [],
    });
    console.log("Token verified!");
  } catch (error: any) {
    if (error.message.toLowerCase().includes("already verified")) {
      console.log("Contract already verified!");
    } else {
      console.error("Verification failed:", error);
    }
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
