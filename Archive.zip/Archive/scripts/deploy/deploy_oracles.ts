import { ethers } from "hardhat";

async function main() {
  console.log("Deploying Oracle Contracts...");

  const initialPrice = ethers.parseEther("1");

  const PriceOracle = await ethers.getContractFactory("PriceOracle");
  const priceOracle = await PriceOracle.deploy(initialPrice);
  await priceOracle.waitForDeployment();
  console.log("PriceOracle deployed to:", await priceOracle.getAddress());

  const VolatilityOracle = await ethers.getContractFactory("VolatilityOracle");
  const volatilityOracle = await VolatilityOracle.deploy();
  await volatilityOracle.waitForDeployment();
  console.log("VolatilityOracle deployed to:", await volatilityOracle.getAddress());
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
