import { ethers } from "hardhat";

async function main() {
  console.log("Deploying Governance Contracts...");

  const [deployer] = await ethers.getSigners();
  const tokenAddress = process.env.TOKEN_ADDRESS || "";

  const minDelay = 2 * 24 * 60 * 60;
  const proposers: string[] = [];
  const executors: string[] = [];
  const admin = deployer.address;

  const TimelockController = await ethers.getContractFactory("TimelockController");
  const timelock = await TimelockController.deploy(
    minDelay,
    proposers,
    executors,
    admin
  );
  await timelock.waitForDeployment();
  const timelockAddress = await timelock.getAddress();
  console.log("TimelockController deployed to:", timelockAddress);

  const GovernorBravo = await ethers.getContractFactory("GovernorBravo");
  const governor = await GovernorBravo.deploy(tokenAddress, timelockAddress);
  await governor.waitForDeployment();
  console.log("GovernorBravo deployed to:", await governor.getAddress());

  const QuorumCalculator = await ethers.getContractFactory("QuorumCalculator");
  const quorumCalculator = await QuorumCalculator.deploy(4, 2, 10);
  await quorumCalculator.waitForDeployment();
  console.log("QuorumCalculator deployed to:", await quorumCalculator.getAddress());
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
