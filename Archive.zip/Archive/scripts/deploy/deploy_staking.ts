import { ethers } from "hardhat";

async function main() {
  console.log("Deploying Staking Contracts...");

  const [deployer] = await ethers.getSigners();
  
  const tokenAddress = process.env.TOKEN_ADDRESS || "";
  const rewardRate = ethers.parseEther("100");

  const StakingPool = await ethers.getContractFactory("StakingPool");
  const stakingPool = await StakingPool.deploy(
    tokenAddress,
    tokenAddress,
    rewardRate
  );
  await stakingPool.waitForDeployment();
  console.log("StakingPool deployed to:", await stakingPool.getAddress());

  const VeToken = await ethers.getContractFactory("VeToken");
  const veToken = await VeToken.deploy(tokenAddress);
  await veToken.waitForDeployment();
  console.log("VeToken deployed to:", await veToken.getAddress());

  const RewardDistributor = await ethers.getContractFactory("RewardDistributor");
  const rewardDistributor = await RewardDistributor.deploy(tokenAddress);
  await rewardDistributor.waitForDeployment();
  console.log("RewardDistributor deployed to:", await rewardDistributor.getAddress());
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
