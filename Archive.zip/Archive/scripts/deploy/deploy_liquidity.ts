import { ethers } from "hardhat";

async function main() {
  console.log("Deploying Liquidity Contracts...");

  const [deployer] = await ethers.getSigners();

  const positionManagerAddress = "0xC36442b4a4522E871399CD717aBDD847Ab11FE88";
  const swapRouterAddress = "0xE592427A0AEce92De3Edee1F18E0157C05861564";

  const LiquidityManager = await ethers.getContractFactory("LiquidityManager");
  const liquidityManager = await LiquidityManager.deploy(
    positionManagerAddress,
    swapRouterAddress
  );
  await liquidityManager.waitForDeployment();
  console.log("LiquidityManager deployed to:", await liquidityManager.getAddress());

  const LiquidityLocker = await ethers.getContractFactory("LiquidityLocker");
  const liquidityLocker = await LiquidityLocker.deploy();
  await liquidityLocker.waitForDeployment();
  console.log("LiquidityLocker deployed to:", await liquidityLocker.getAddress());
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
