import { ethers } from "hardhat";

async function main() {
  console.log("Deploying Treasury Contracts...");

  const [deployer] = await ethers.getSigners();
  const tokenAddress = process.env.TOKEN_ADDRESS || "";

  const Treasury = await ethers.getContractFactory("Treasury");
  const treasury = await Treasury.deploy(deployer.address);
  await treasury.waitForDeployment();
  const treasuryAddress = await treasury.getAddress();
  console.log("Treasury deployed to:", treasuryAddress);

  const swapRouterAddress = "0xE592427A0AEce92De3Edee1F18E0157C05861564";

  const BuybackAndBurn = await ethers.getContractFactory("BuybackAndBurn");
  const buybackAndBurn = await BuybackAndBurn.deploy(
    tokenAddress,
    swapRouterAddress,
    treasuryAddress
  );
  await buybackAndBurn.waitForDeployment();
  console.log("BuybackAndBurn deployed to:", await buybackAndBurn.getAddress());

  const FundDistributor = await ethers.getContractFactory("FundDistributor");
  const fundDistributor = await FundDistributor.deploy();
  await fundDistributor.waitForDeployment();
  console.log("FundDistributor deployed to:", await fundDistributor.getAddress());
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
