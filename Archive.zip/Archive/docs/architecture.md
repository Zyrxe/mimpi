# MIMPI Token Architecture

## System Overview

The MIMPI Token ecosystem consists of multiple interconnected smart contracts designed for a comprehensive DeFi platform.

## Core Token Contract

### MIMPIToken.sol

**Pattern**: UUPS Upgradeable Proxy
**Base Contracts**:
- ERC20Upgradeable
- ERC20BurnableUpgradeable
- ERC20PausableUpgradeable
- ERC20PermitUpgradeable
- ERC20SnapshotUpgradeable
- ERC20VotesUpgradeable
- AccessControlUpgradeable

**Key Features**:
- Upgradeable via UUPS pattern
- Role-based access control (MINTER, PAUSER, UPGRADER, SNAPSHOT)
- Initial supply: 1B tokens with 5% auto-burn
- Gasless approvals via EIP-2612
- Governance voting capabilities

## Liquidity Management

### LiquidityLocker.sol
Locks LP tokens for specified duration to ensure liquidity stability.

**Features**:
- Time-locked LP token storage
- Beneficiary-based unlocking
- Lock extension capability

### LPTokenWrapper.sol
Wraps LP tokens for use in staking pools.

## Staking System

### StakingPool.sol
Multi-pool staking with dynamic reward distribution.

**Mechanism**:
- Stake MP tokens
- Earn rewards over time
- Reward rate adjustable by owner
- Emergency withdraw option

### VeToken.sol
Vote-Escrowed tokens for governance participation.

**Features**:
- Lock tokens for voting power
- Longer lock = higher voting weight
- Lock duration: 7 days to 4 years
- Voting power decays linearly

### RewardDistributor.sol
Manages scheduled reward distributions across multiple pools.

## Treasury Management

### Treasury.sol
Multi-signature treasury with role-based withdrawals.

**Roles**:
- TREASURER: Can deposit funds
- WITHDRAWER: Can withdraw funds
- DEFAULT_ADMIN: Full control

### FundDistributor.sol
Distributes funds to multiple recipients based on percentage allocation.

## Vesting System

### TokenVesting.sol
Individual vesting contract with cliff and linear vesting.

### TeamVestingFactory.sol
Factory for deploying multiple team vesting contracts.

### InvestorVesting.sol
Manages multiple investor vesting schedules with revocation capability.

## Oracles & Monitoring

### PriceOracle.sol
Tracks token price for ecosystem functions.

### VolatilityOracle.sol
Calculates price volatility using historical data.

### CircuitBreaker.sol
Emergency pause mechanism based on threshold violations.

**Features**:
- Event counting in time windows
- Automatic pause on threshold breach
- Cooldown period before reset

### EventLogger.sol
Comprehensive event logging for all ecosystem activities.

## Security Considerations

1. **Access Control**: All administrative functions use OpenZeppelin's AccessControl
2. **Upgradeability**: UUPS pattern prevents unauthorized upgrades
3. **Pausability**: Emergency pause for critical situations
4. **Reentrancy Protection**: ReentrancyGuard on all value transfers
5. **Input Validation**: Comprehensive checks on all parameters

## Deployment Sequence

1. Deploy MIMPIToken (via UUPS proxy)
2. Deploy Treasury
3. Deploy Staking contracts
4. Deploy Vesting contracts
5. Deploy Oracles
6. Deploy Monitoring contracts
7. Configure roles and permissions
8. Transfer initial token allocations

## Gas Optimization

- Use of `immutable` for constant addresses
- Efficient storage layout
- Batch operations where possible
- Minimal storage reads/writes

## Future Enhancements

- Layer 2 deployment
- Cross-chain bridging
- Advanced yield strategies
- Automated market making
